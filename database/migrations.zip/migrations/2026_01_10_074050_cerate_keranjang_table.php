<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('keranjang', function (Blueprint $table) {

            $table->id('id_keranjang');

            // USER
            $table->unsignedBigInteger('id_user');

            // BUKU
            $table->unsignedBigInteger('id_buku');

            $table->integer('durasi');
            $table->date('tanggal_mulai');
            $table->date('tanggal_selesai');
            $table->integer('harga_total');

            $table->enum('status', ['cart','checkout'])
                  ->default('cart');

            $table->timestamps();

            // FOREIGN KEY USER
            $table->foreign('id_user')
                  ->references('id_user')
                  ->on('users')
                  ->cascadeOnDelete();

            // FOREIGN KEY BUKU
            $table->foreign('id_buku')
                  ->references('id_buku')
                  ->on('buku')
                  ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('keranjang');
    }
};
